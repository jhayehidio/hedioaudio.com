# BoundaryEQ - Installation Guide

Thank you for purchasing BoundaryEQ! Follow these simple steps to install the plugin on your system.

## Windows Installation
1.  Locate your system's VST3 folder. The standard location is:
    `C:\Program Files\Common Files\VST3`
2.  Copy the `BoundaryEQ.vst3` folder into this folder.
3.  Restart your DAW.
4.  Scan for new plugins if your DAW doesn't do it automatically.

## Support
If you have any issues, please visit: https://hedioaudio.com
