# BoundaryEQ - Installation Guide

Thank you for trying out BoundaryEQ! This trial gives you full access to the plugin's features so you can experience the workflow in your own projects.

## Windows Installation
1.  Locate your system's VST3 folder. The standard location is:
    `C:\Program Files\Common Files\VST3`
2.  Copy the `BoundaryEQ.vst3` folder into this folder.
3.  Restart your DAW.
4.  Scan for new plugins if your DAW doesn't do it automatically.

## Support
If you have any issues, please visit: https://hedioaudio.com
